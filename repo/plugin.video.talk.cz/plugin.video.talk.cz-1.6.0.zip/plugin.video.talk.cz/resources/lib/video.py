import threading
import time
import re
import xbmc
import xbmcgui
import xbmcplugin
from bs4 import BeautifulSoup
from .auth import get_session, require_session
from .constants import _HANDLE, _ADDON
from .utils import get_url, log, get_image_path

# Global progress monitor instance
_progress_monitor = None
_monitor_lock = threading.Lock()

def play_video(video_url, requested_quality=None, start_time=None):
    """
    Play a video from the provided URL with optional quality and start time

    Args:
        video_url (str): URL of the video to play
        requested_quality (str): Optional quality preference (Auto, 1080p, 720p, 480p, 360p, 240p)
        start_time (int): Optional start time in seconds for video playback

    Example:
        play_video('https://www.talktv.cz/video/1726/marcel-kolaja-regulace-ai-cookie-listy-tiktok-a-bezpecnost-monopoly-na-trhu-a-ochrana-spotrebitele-papirova-brcka', '720p', 300)
    """

    # Get a session for making HTTP requests
    session = require_session()
    if not session:
        return

    try:
        log(f"Attempting to play video: {video_url}", xbmc.LOGINFO)
        response = session.get(video_url)
        if response.status_code != 200:
            log(f"Failed to fetch video page: {response.status_code}", xbmc.LOGERROR)
            return

        # Parse the HTML response
        soup = BeautifulSoup(response.text, 'html.parser')
        video_element = soup.find('video-js')
        if not video_element:
            log("Video player element not found in page", xbmc.LOGERROR)
            return

        # Get stream type and quality preferences
        prefer_hls = int(_ADDON.getSetting('preferred_stream')) == 0  # 0=HLS, 1=MP4
        if not requested_quality:
            quality_index = int(_ADDON.getSetting('video_quality'))
            qualities = ['Auto', '1080p', '720p', '480p', '360p', '240p']
            requested_quality = qualities[quality_index]

        # Find the best available source
        sources = video_element.find_all('source')
        selected_url = None
        use_hls = False

        # Try HLS for Auto quality when HLS is preferred
        if requested_quality.lower() == 'auto' and prefer_hls:
            for source in sources:
                if source.get('type') == 'application/x-mpegURL':
                    selected_url = source['src']
                    use_hls = True
                    log("Selected HLS stream for auto quality", xbmc.LOGINFO)
                    break

        # If no HLS selected or MP4 preferred, try MP4
        if not selected_url:
            qualities = ['1080p', '720p', '480p', '360p', '240p']
            if requested_quality != 'Auto':
                # Start from requested quality
                start_idx = qualities.index(requested_quality)
                qualities = qualities[start_idx:]

            for quality in qualities:
                for source in sources:
                    if (source.get('type') == 'video/mp4' and
                        quality in source.get('src', '')):
                        selected_url = source['src']
                        log(f"Selected {quality} MP4 stream", xbmc.LOGINFO)
                        break
                if selected_url:
                    break

        # Fallback to first available source
        if not selected_url and sources:
            selected_url = sources[0]['src']
            log("Falling back to first available source", xbmc.LOGWARNING)

        if not selected_url:
            log("No playable source found", xbmc.LOGERROR)
            xbmcplugin.setResolvedUrl(_HANDLE, False, xbmcgui.ListItem())
            return

        # Setup playback
        play_item = xbmcgui.ListItem(path=selected_url)

        # Configure inputstream
        if use_hls:
            play_item.setMimeType('application/x-mpegURL')
            play_item.setProperty('inputstream', 'inputstream.adaptive')
        else:
            play_item.setMimeType('video/mp4')

        play_item.setContentLookup(False)

        try:
            # Get main details info
            details = soup.find('div', class_='details__info')
            description = ''

            if details:
                main_content = details.text.strip()
                parts = main_content.split('                -', 1)
                if len(parts) == 2:
                    description = parts[1].strip()
                else:
                    description = main_content

            # Get additional description if available
            description_element = soup.find('div', class_='details__description-text')
            if description_element:
                additional_description = description_element.text.strip()
                if additional_description:
                    # Only add newline if we have both descriptions
                    if description:
                        description += '\n\n' + additional_description
                    else:
                        description = additional_description

            # Get title if available
            title = soup.find('h1', class_='details__header')
            if title:
                title = title.text.strip()

            # Set video metadata
            info_tag = play_item.getVideoInfoTag()
            info_tag.setMediaType('video')
            if description:
                info_tag.setPlot(description)
            if title:
                info_tag.setTitle(title)

        except Exception as e:
            log(f"Failed to set video metadata: {str(e)}", xbmc.LOGWARNING)

        # Handle start time if specified
        if start_time:
            monitor = get_progress_monitor()
            monitor.initial_position = start_time
            log(f"Setting initial position to {start_time}s", xbmc.LOGINFO)

        # Extract and store video ID
        #
        # Original JS code on the video page footer:
        # initPlayerComponent({
        #     "videoTitle":"Marcel Kolaja: regulace AI, cookie lišty, TikTok a bezpečnost, monopoly na trhu a ochrana spotřebitele, papírová brčka...",
        #     "posterUrl":"https://static.talktv.cz/upload/videos/gl4vZ6yK-poster-sGox3q.jpg",
        #->   "videoId":1726,
        #     "debugMode":false,
        #     "overrideNative":true,
        #     "overrideChromecastSource":false,
        #     "overrideChromecastSourceOriginal":false,
        #     "canShowChromecastWarning":true,
        #     "canShowChromecastRevert":false,
        #     "videoFallbackUrl":"https://vz-b80bf3f2-495.b-cdn.net/bcdn_token=isq0PSmvxnfa054B4A9CTah_xT-L3gfS9OfvqCMp4do&expires=1735482522&token_path=%2Ffbed3ada-c002-475d-9545-d5e679746370/fbed3ada-c002-475d-9545-d5e679746370/play_720p.mp4",
        #     "ssVideoPos":5899,
        #     "ssVideoTime":1735309692
        # });
        try:
            scripts = soup.find_all('script')
            for script in scripts:
                if script.string and 'initPlayerComponent' in script.string:
                    match = re.search(r'"videoId":(\d+)', script.string)
                    if match:
                        monitor = get_progress_monitor()
                        monitor.video_id = match.group(1)
                        break
        except Exception as e:
            log(f"Error extracting video ID: {str(e)}", xbmc.LOGERROR)

        # Start playback
        xbmcplugin.setResolvedUrl(_HANDLE, True, listitem=play_item)

    except Exception as e:
        log(f"Error during video playback setup: {str(e)}", xbmc.LOGERROR)
        xbmcplugin.setResolvedUrl(_HANDLE, False, xbmcgui.ListItem())

def select_quality(video_url):
    """
    Allows the user to select the quality of the video to play from the given URL

    Args:
        video_url (str): URL of the video to play
    """

    # Handle quality selection via dialog
    qualities = ['Auto', '1080p', '720p', '480p', '360p', '240p']
    dialog = xbmcgui.Dialog()
    selected = dialog.select('Vyberte kvalitu', qualities)

    if selected >= 0:  # If user didn't cancel
        quality = qualities[selected]
        # Create a new list item and play it
        play_item = xbmcgui.ListItem(path=get_url(action='play', video_url=video_url, quality=quality))
        xbmc.Player().play(item=get_url(action='play', video_url=video_url, quality=quality), listitem=play_item)

def skip_yt_part(video_url):
    """
    Skips a specific part of a YouTube video based on the provided URL

    Args:
        video_url (str): URL of the YouTube video to play
    """

    try:
        # Get the skip time from settings (in minutes)
        skip_time = int(_ADDON.getSetting('skip_yt_time'))

        # Convert minutes to seconds for the seek parameter
        seek_time = skip_time * 60

        # Create a new list item and play it with the seek time
        play_item = xbmcgui.ListItem(path=get_url(action='play', video_url=video_url))
        info_tag = play_item.getVideoInfoTag()
        info_tag.setResumePoint(seek_time)  # Set resume point to skip YouTube portion

        # Start playback from the specified time
        xbmc.Player().play(item=get_url(action='play', video_url=video_url), listitem=play_item)

        return True
    except Exception as e:
        log(f'Error in skip_yt_part: {str(e)}', xbmc.LOGERROR)
        return False

def yt_live():
    """
    Create directory with two stream options: public (Čumilové) and VIP

    Note: This function requires the YouTube addon to be installed
    """

    try:
        # Check if YouTube addon is installed
        import xbmcaddon
        try:
            youtube_addon = xbmcaddon.Addon('plugin.video.youtube')
        except:
            log("YouTube addon not installed", xbmc.LOGERROR)
            xbmcgui.Dialog().ok('Chyba', 'Doplněk YouTube není nainstalován, nainstalujte jej pro zobrazení živých streamů.')
            return False

        # STANDASHOW YouTube channel ID
        # https://www.youtube.com/@StandaShow
        # https://www.youtube.com/channel/UCeDNCzyWtX6Y1ThbVuxbrtw
        channel_id = 'UCeDNCzyWtX6Y1ThbVuxbrtw'

        # Construct the URL for the public live streams page
        youtube_url = f'plugin://plugin.video.youtube/channel/{channel_id}/live/'

        log(f"Creating directory items for live streams", xbmc.LOGINFO)

        # Create list item for public stream (Čumilové stream)
        list_item_public = xbmcgui.ListItem(label='Čumil stream')
        info_tag_public = list_item_public.getVideoInfoTag()
        info_tag_public.setTitle('Čumil stream')
        info_tag_public.setPlot('Veřejné živé streamy na YouTube kanálu [COLOR limegreen]STANDASHOW[/COLOR].\n\n[COLOR slategrey]Poznámka: Otevře doplněk YouTube v sekci živých přenosů na kanálu @StandaShow.[/COLOR]')

        # Add the public stream directory item
        xbmcplugin.addDirectoryItem(_HANDLE, youtube_url, list_item_public, True)

        # Create list item for VIP stream
        list_item_vip = xbmcgui.ListItem(label='VIP stream')
        info_tag_vip = list_item_vip.getVideoInfoTag()
        info_tag_vip.setTitle('VIP stream')
        info_tag_vip.setPlot('Exkluzivní VIP stream pro předplatitele [COLOR limegreen]TALK[/COLOR]u.\n\n[COLOR slategrey]Poznámka: Otevře živý přenos na YouTube kanálu @StandaShowEXTRA.\n\nStream musí být aktivní na talktv.cz.[/COLOR]')

        image_path = get_image_path('fa-video-solid-full.png')
        list_item_vip.setArt({
            'thumb': image_path,
            'icon': image_path
        })

        # Add the VIP stream directory item
        vip_url = get_url(action='vip_stream')
        xbmcplugin.addDirectoryItem(_HANDLE, vip_url, list_item_vip, isFolder=False)

        # Set the plugin category and content type
        xbmcplugin.setPluginCategory(_HANDLE, 'Živě')
        xbmcplugin.setContent(_HANDLE, 'files')
        xbmcplugin.endOfDirectory(_HANDLE)

        return True

    except Exception as e:
        log(f'Error in yt_live: {str(e)}', xbmc.LOGERROR)
        xbmcgui.Dialog().notification('Chyba', str(e))
        return False

def yt_vip_stream():
    """
    Check TALK.cz homepage for VIP stream link and open it in YouTube addon

    The VIP stream link is located in:
    body > div.container > main > a.hero.hero--secondary.hero--link
    """

    try:
        # Check if YouTube addon is installed
        import xbmcaddon
        try:
            youtube_addon = xbmcaddon.Addon('plugin.video.youtube')
        except:
            log("YouTube addon not installed", xbmc.LOGERROR)
            xbmcgui.Dialog().ok('Chyba', 'Doplněk YouTube není nainstalován, nainstalujte jej pro zobrazení živých streamů.')
            return False

        # Get authenticated session
        session = require_session()
        if not session:
            return False

        log("Fetching VIP stream from TALK.cz homepage", xbmc.LOGINFO)

        # Fetch the homepage
        response = session.get('https://www.talktv.cz/')
        if response.status_code != 200:
            log(f"Failed to fetch homepage: {response.status_code}", xbmc.LOGERROR)
            xbmcgui.Dialog().notification('Chyba', 'Nepodařilo se načíst hlavní stránku')
            return False

        # Parse the HTML
        soup = BeautifulSoup(response.text, 'html.parser')

        # Find VIP stream link
        # Looking for: body > div.container > main > a.hero.hero--secondary.hero--link
        vip_link = soup.select_one('body > div.container > main > a.hero.hero--secondary.hero--link')

        if not vip_link or not vip_link.get('href'):
            log("VIP stream link not found on homepage", xbmc.LOGWARNING)
            xbmcgui.Dialog().notification('VIP stream', 'VIP stream momentálně není dostupný')
            return False

        youtube_url = vip_link['href']
        log(f"Found VIP stream URL: {youtube_url}", xbmc.LOGINFO)

        # Check if the URL is actually a YouTube URL
        if 'youtube.com' not in youtube_url and 'youtu.be' not in youtube_url:
            log(f"Link is not a YouTube URL: {youtube_url}", xbmc.LOGWARNING)
            xbmcgui.Dialog().notification('VIP stream', 'VIP stream momentálně není dostupný')
            return False

        # Extract video ID from YouTube URL
        # Possible formats:
        # https://youtube.com/live/u7sOFSAJY4Y
        # https://www.youtube.com/watch?v=u7sOFSAJY4Y
        video_id = None
        if '/live/' in youtube_url:
            video_id = youtube_url.split('/live/')[-1].split('?')[0]
        elif 'watch?v=' in youtube_url:
            video_id = youtube_url.split('watch?v=')[-1].split('&')[0]

        if not video_id:
            log(f"Could not extract video ID from URL: {youtube_url}", xbmc.LOGERROR)
            xbmcgui.Dialog().notification('Chyba', 'Neplatný formát YouTube URL')
            return False

        # Construct YouTube plugin URL
        yt_plugin_url = f'plugin://plugin.video.youtube/play/?video_id={video_id}'

        log(f"Opening VIP stream in YouTube addon: {yt_plugin_url}", xbmc.LOGINFO)

        # Create list item and play
        list_item = xbmcgui.ListItem(label='VIP stream')
        xbmc.Player().play(item=yt_plugin_url, listitem=list_item)

        return True

    except Exception as e:
        log(f'Error in yt_vip_stream: {str(e)}', xbmc.LOGERROR)
        xbmcgui.Dialog().notification('Chyba', 'Chyba při načítání VIP streamu')
        return False

def resume_from_web(video_url):
    """
    Resume playback from the web position.

    Args:
        video_url (str): URL of the video to resume
    """

    try:
        web_position = check_web_resume(video_url)
        if web_position:
            # Convert seconds to readable time format
            hours = web_position // 3600
            minutes = (web_position % 3600) // 60
            seconds = web_position % 60

            if hours > 0:
                time_str = f'{hours}:{minutes:02d}:{seconds:02d}'
            else:
                time_str = f'{minutes}:{seconds:02d}'

            # Ask user if they want to resume from this position
            dialog = xbmcgui.Dialog()
            resume = dialog.yesno('Pokračovat v přehrávání', f'Chcete pokračovat v přehrávání od času {time_str}?')

            if resume:
                # Create a new list item with the start position
                play_item = xbmcgui.ListItem(path=get_url(action='play', video_url=video_url))
                info_tag = play_item.getVideoInfoTag()
                info_tag.setResumePoint(web_position)  # Set resume point to continue from web position

                # Start playback from the specified time
                xbmc.Player().play(item=get_url(action='play', video_url=video_url), listitem=play_item)
                return True
            else:
                return False

        # No web position or user declined to resume
        dialog = xbmcgui.Dialog()
        start = dialog.yesno('Přehrát od začátku', 'Žádná uložená pozice sledování na webu.\nChcete spustit přehrávání od začátku?')

        if start:
            # Create a new list item without start position
            play_item = xbmcgui.ListItem(path=get_url(action='play', video_url=video_url))
            xbmc.Player().play(item=get_url(action='play', video_url=video_url), listitem=play_item)
            return True

        return False

    except Exception as e:
        log(f'Error in resume_from_web: {str(e)}', xbmc.LOGERROR)
        xbmcgui.Dialog().notification('Chyba', str(e))
        return False

def check_web_resume(video_url):
    """
    Check if there's a resume point on the web.

    Args:
        video_url (str): URL of the video to check

    Returns:
        int: Web resume position in seconds

    Original JS code on the video page footer:
    initPlayerComponent({
        "videoTitle":"Marcel Kolaja: regulace AI, cookie lišty, TikTok a bezpečnost, monopoly na trhu a ochrana spotřebitele, papírová brčka...",
        "posterUrl":"https://static.talktv.cz/upload/videos/gl4vZ6yK-poster-sGox3q.jpg",
        "videoId":1726,
        "debugMode":false,
        "overrideNative":true,
        "overrideChromecastSource":false,
        "overrideChromecastSourceOriginal":false,
        "canShowChromecastWarning":true,
        "canShowChromecastRevert":false,
        "videoFallbackUrl":"https://vz-b80bf3f2-495.b-cdn.net/bcdn_token=isq0PSmvxnfa054B4A9CTah_xT-L3gfS9OfvqCMp4do&expires=1735482522&token_path=%2Ffbed3ada-c002-475d-9545-d5e679746370/fbed3ada-c002-475d-9545-d5e679746370/play_720p.mp4",
    ->  "ssVideoPos":5899,
        "ssVideoTime":1735309692
    });
    """

    try:
        session = get_session()
        if not session:
            return None

        response = session.get(video_url)
        if response.status_code != 200:
            return None

        soup = BeautifulSoup(response.text, 'html.parser')
        scripts = soup.find_all('script')
        for script in scripts:
            if script.string and 'initPlayerComponent' in script.string:
                pos_match = re.search(r'"ssVideoPos":(\d+)', script.string)
                if pos_match:
                    return int(pos_match.group(1))
    except Exception as e:
        log(f"Error checking web resume point: {str(e)}", xbmc.LOGERROR)
    return None

def get_progress_monitor():
    """
    Get or create the progress monitor singleton instance.
    """
    global _progress_monitor
    with _monitor_lock:
        if _progress_monitor is None:
            _progress_monitor = ProgressMonitor()
            log("Created new ProgressMonitor instance", xbmc.LOGINFO)
        return _progress_monitor

def clear_progress_monitor():
    """
    Clear the global progress monitor instance after cleanup.
    """
    global _progress_monitor
    with _monitor_lock:
        if _progress_monitor is not None:
            _progress_monitor.cleanup()
            _progress_monitor = None
            log("Cleared global ProgressMonitor instance", xbmc.LOGINFO)

class ProgressMonitor(xbmc.Player):
    """
    Progress monitor class to track video playback progress and send updates to the server.

    Note: This class extends the xbmc.Player class to inherit playback methods.
    """

    def __init__(self):
        super().__init__()
        self._video_id = None
        self.monitor = xbmc.Monitor()
        self.session = None
        self.stop_thread = False
        self.progress_thread = None
        self.initial_position = 0  # Add this new property
        self._cleanup_called = False
        log("ProgressMonitor initialized", xbmc.LOGINFO)

    def __del__(self):
        """Destructor to ensure cleanup when object is garbage collected"""
        if not self._cleanup_called:
            log("ProgressMonitor destructor called, cleaning up", xbmc.LOGINFO)
            self.cleanup()

    def __enter__(self):
        """Context manager entry"""
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        """Context manager exit - ensures cleanup"""
        self.cleanup()
        return False  # Don't suppress exceptions

    @property
    def video_id(self):
        return self._video_id

    @video_id.setter
    def video_id(self, value):
        self._video_id = value
        if value:
            log(f"Video ID set to: {value}", xbmc.LOGINFO)
            self._start_monitoring()

    def _start_monitoring(self):
        # Start the monitoring thread.

        try:
            # Get a new session
            self.session = get_session()
            if not self.session:
                log("Failed to get session for monitoring", xbmc.LOGERROR)
                return

            # Stop existing thread if running
            if self.progress_thread and self.progress_thread.is_alive():
                log("Stopping existing progress thread", xbmc.LOGINFO)
                self.stop_thread = True
                try:
                    self.progress_thread.join(timeout=3.0)
                    if self.progress_thread.is_alive():
                        log("Previous thread did not stop within timeout", xbmc.LOGWARNING)
                except Exception as e:
                    log(f"Error stopping previous thread: {str(e)}", xbmc.LOGERROR)

            # Start new monitoring thread
            self.stop_thread = False
            self.progress_thread = threading.Thread(target=self.monitor_progress)
            self.progress_thread.daemon = True
            self.progress_thread.start()
            log(f"Started progress monitoring thread for video {self.video_id}", xbmc.LOGINFO)
        except Exception as e:
            log(f"Error starting monitoring: {str(e)}", xbmc.LOGERROR)

    def cleanup(self):
        """Clean up resources and stop monitoring with proper timeout protection"""
        if self._cleanup_called:
            return

        log("Cleanup called", xbmc.LOGINFO)
        self._cleanup_called = True

        # Stop the monitoring thread
        if self.progress_thread and self.progress_thread.is_alive():
            log("Stopping progress monitoring thread", xbmc.LOGINFO)
            self.stop_thread = True

            # Wait for thread to finish with timeout
            try:
                self.progress_thread.join(timeout=5.0)
                if self.progress_thread.is_alive():
                    log("Thread did not stop within timeout", xbmc.LOGWARNING)
                else:
                    log("Progress monitoring thread stopped successfully", xbmc.LOGINFO)
            except Exception as e:
                log(f"Error joining progress thread: {str(e)}", xbmc.LOGERROR)

        # Close session if it exists
        if self.session:
            try:
                self.session.close()
                log("Session closed", xbmc.LOGDEBUG)
            except Exception as e:
                log(f"Error closing session: {str(e)}", xbmc.LOGWARNING)

        # Reset all attributes
        self._video_id = None
        self.session = None
        self.progress_thread = None
        self.stop_thread = False
        self.initial_position = 0

        log("ProgressMonitor cleanup completed", xbmc.LOGINFO)

    def monitor_progress(self):
        """Monitor video progress and send updates to server with full exception protection"""
        try:
            log("Starting progress monitoring loop", xbmc.LOGINFO)
            self._monitor_progress_internal()
        except Exception as e:
            log(f"Critical error in progress monitoring: {str(e)}", xbmc.LOGERROR)
        finally:
            log("Progress monitoring thread ending", xbmc.LOGINFO)

    def _monitor_progress_internal(self):

        # Wait for playback to start
        attempt = 0
        while attempt < 10 and (not self.isPlaying() or not self.isPlayingVideo()):
            xbmc.sleep(1000)
            attempt += 1
            log(f"Waiting for playback to start (attempt {attempt})", xbmc.LOGINFO)

        # If we have an initial position and playback has started, seek to it
        if self.initial_position > 0 and self.isPlaying() and self.isPlayingVideo():
            log(f"Seeking to initial position: {self.initial_position}", xbmc.LOGINFO)
            self.seekTime(self.initial_position)
            xbmc.sleep(1000)  # Give time for seek to complete

        while not self.monitor.abortRequested() and not self.stop_thread:
            try:
                if self.video_id and self.session and self.isPlaying() and self.isPlayingVideo():
                    current_time = self.getTime()

                    # Only send updates if we have a valid time
                    if current_time > 0:
                        # Send progress update to server
                        log(f"Sending progress update for video {self.video_id} at position {int(current_time)}", xbmc.LOGINFO)
                        response = self.session.get(
                            'https://www.talktv.cz/srv/log-time',
                            params={
                                'vid': self.video_id,
                                'p': int(current_time),
                                't': int(time.time()),
                                's': 30
                            },
                            timeout=10
                        )

                        if response.status_code == 200:
                            log(f"Progress updated for video {self.video_id} at position {int(current_time)}", xbmc.LOGINFO)
                        else:
                            log(f"Failed to update progress: {response.status_code}", xbmc.LOGWARNING)
                else:
                    if not self.isPlaying() or not self.isPlayingVideo():
                        xbmc.sleep(1000)  # Wait a bit before checking again
                        continue
            except Exception as e:
                log(f"Error in progress monitoring: {str(e)}", xbmc.LOGWARNING)

            # Wait for 30 seconds before next update
            for _ in range(30):
                if self.monitor.waitForAbort(1) or self.stop_thread or not self.isPlaying():
                    return

        log("Progress monitoring loop ended", xbmc.LOGINFO)
        self.initial_position = 0
